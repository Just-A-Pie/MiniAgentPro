using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections;
using System.Collections.Generic;

public class SimulationPlaybackController : MonoBehaviour
{
    [Header("���ſ��� UI")]
    public Button playButton;
    public Button pauseButton;
    public Button jumpButton;
    public TMP_Dropdown speedDropdown; // ѡ�1x,2x,4x,8x
    public TMP_InputField jumpStepInput; // ��ʾ/����Ŀ�� step

    [Header("Agent ��Ⱦ")]
    public SimulationAgentRenderer agentRenderer; // ������ mapContent ��

    [Header("���Ų���")]
    public float baseStepDuration = 1f;

    [Header("������������")]
    public string simFolderPath; // �Զ��� GameManager.Instance.simPath ��Ĭ��·����ȡ

    [Header("�첽�������")]
    public LoadingPanelController loadingPanel; // ���볡���� LoadingPanel �Ŀ��ƽű�
    public AsyncSimulationDataLoader dataLoader;  // ���� AsyncSimulationDataLoader ����

    private List<Dictionary<string, SimulationAgent>> simulationSteps;
    private int currentStepIndex = 0;
    private Coroutine playbackCoroutine;
    private bool isPaused = false;
    private float speedMultiplier = 1f;

    private int gridWidth = 0;
    private int gridHeight = 0;

    private void Start()
    {
        Time.timeScale = 1f;

        // ��ʾ Loading Panel
        if (loadingPanel != null)
            loadingPanel.Show();

        // �Զ���ȡ simFolderPath
        if (string.IsNullOrEmpty(simFolderPath))
        {
            if (GameManager.Instance != null && !string.IsNullOrEmpty(GameManager.Instance.simPath))
                simFolderPath = GameManager.Instance.simPath;
            else
                simFolderPath = System.IO.Path.Combine(Application.dataPath, "Sim");
        }
        Debug.Log("ʹ�õ� sim �ļ���·��: " + simFolderPath);

        // �����첽���ݼ���
        if (dataLoader != null)
        {
            dataLoader.simFolderPath = simFolderPath;
            dataLoader.OnDataLoaded += OnDataLoaded;
        }
        else
        {
            Debug.LogError("δ�ҵ� AsyncSimulationDataLoader ����");
        }
    }

    private void OnDataLoaded()
    {
        // ���ݼ�����ɺ����� Loading Panel
        if (loadingPanel != null)
            loadingPanel.Hide();

        simulationSteps = dataLoader.simulationSteps;
        if (simulationSteps == null || simulationSteps.Count == 0)
        {
            Debug.LogError("���ݼ��غ� simulationSteps Ϊ�գ�");
            return;
        }
        currentStepIndex = 0;
        agentRenderer.RenderAgents(simulationSteps[currentStepIndex]);
        jumpStepInput.text = currentStepIndex.ToString();

        if (SimulationMapManager.Instance != null && SimulationMapManager.Instance.mapImage != null)
        {
            Vector2 mapSize = SimulationMapManager.Instance.mapImage.rectTransform.sizeDelta;
            float factor = SimulationMapManager.Instance.backgroundScaleFactor;
            float origWidth = mapSize.x / factor;
            float origHeight = mapSize.y / factor;
            gridWidth = Mathf.FloorToInt(origWidth / agentRenderer.gridSize);
            gridHeight = Mathf.FloorToInt(origHeight / agentRenderer.gridSize);
            Debug.Log($"���������Χ: {gridWidth} x {gridHeight}");
        }

        if (playButton != null)
            playButton.onClick.AddListener(OnPlayButtonClicked);
        if (pauseButton != null)
            pauseButton.onClick.AddListener(OnPauseButtonClicked);
        if (jumpButton != null)
            jumpButton.onClick.AddListener(OnJumpButtonClicked);
        if (speedDropdown != null)
            speedDropdown.onValueChanged.AddListener(OnSpeedChanged);

        SetPlayPauseInteractable(true, false);
        SetJumpUIInteractable(false);
    }

    private void Update()
    {
        if (!isPaused)
        {
            jumpStepInput.text = currentStepIndex.ToString();
            SetJumpUIInteractable(false);
        }
    }

    #region UI ����
    private void OnPlayButtonClicked()
    {
        if (playbackCoroutine == null)
        {
            isPaused = false;
            SetPlayPauseInteractable(false, true);
            SetJumpUIInteractable(false);
            playbackCoroutine = StartCoroutine(PlaybackCoroutine());
        }
    }

    private void OnPauseButtonClicked()
    {
        isPaused = true;
        if (playbackCoroutine != null)
        {
            StopCoroutine(playbackCoroutine);
            playbackCoroutine = null;
        }
        agentRenderer.UpdateAgentsPositions(simulationSteps[currentStepIndex]);
        SetPlayPauseInteractable(true, false);
        SetJumpUIInteractable(true);
        ForceAgentsIdle();
    }

    private void OnSpeedChanged(int index)
    {
        switch (index)
        {
            case 0: speedMultiplier = 1f; break;
            case 1: speedMultiplier = 2f; break;
            case 2: speedMultiplier = 4f; break;
            case 3: speedMultiplier = 8f; break;
            default: speedMultiplier = 1f; break;
        }
        Debug.Log("����Ϊ: " + speedMultiplier + "x");
    }

    private void OnJumpButtonClicked()
    {
        int targetStep;
        if (int.TryParse(jumpStepInput.text, out targetStep))
        {
            targetStep = Mathf.Clamp(targetStep, 0, simulationSteps.Count - 1);
            currentStepIndex = targetStep;
            Debug.Log("������: " + currentStepIndex);
            agentRenderer.UpdateAgentsPositions(simulationSteps[currentStepIndex]);
        }
        else
        {
            Debug.LogWarning("��Ч����������");
        }
    }

    private void SetPlayPauseInteractable(bool playEnabled, bool pauseEnabled)
    {
        if (playButton != null) playButton.interactable = playEnabled;
        if (pauseButton != null) pauseButton.interactable = pauseEnabled;
    }

    private void SetJumpUIInteractable(bool interactable)
    {
        if (jumpButton != null) jumpButton.interactable = interactable;
        if (jumpStepInput != null) jumpStepInput.interactable = interactable;
    }
    #endregion

    #region ���Ŷ���Э��
    private IEnumerator PlaybackCoroutine()
    {
        while (currentStepIndex < simulationSteps.Count - 1)
        {
            Dictionary<string, SimulationAgent> fromStep = simulationSteps[currentStepIndex];
            Dictionary<string, SimulationAgent> toStep = simulationSteps[currentStepIndex + 1];
            float stepDuration = baseStepDuration / speedMultiplier;
            Debug.Log($"�� step {currentStepIndex} �� {currentStepIndex + 1} ������ʼ����ʱ��: {stepDuration} ��");

            yield return StartCoroutine(AnimateStep(fromStep, toStep, stepDuration));

            currentStepIndex++;
            Debug.Log("������ɣ���ǰ step: " + currentStepIndex);
            agentRenderer.UpdateAgentsPositions(simulationSteps[currentStepIndex]);

            while (isPaused)
                yield return null;
        }
        Debug.Log("���Ž���");
        playbackCoroutine = null;
    }

    private IEnumerator AnimateStep(Dictionary<string, SimulationAgent> fromStep, Dictionary<string, SimulationAgent> toStep, float duration)
    {
        float factor = (SimulationMapManager.Instance != null) ? SimulationMapManager.Instance.backgroundScaleFactor : 1f;
        Debug.Log("AnimateStep: ʹ�ñ�����������: " + factor);

        Dictionary<string, List<Vector2>> agentPaths = new Dictionary<string, List<Vector2>>();
        foreach (var kvp in fromStep)
        {
            string name = kvp.Key;
            Vector2Int startGrid = new Vector2Int(kvp.Value.curr_tile[0], kvp.Value.curr_tile[1]);
            Vector2Int targetGrid = new Vector2Int(toStep[name].curr_tile[0], toStep[name].curr_tile[1]);
            List<Vector2Int> gridPath = AStarPathfinder.GetPath(startGrid, targetGrid, gridWidth, gridHeight);
            List<Vector2> worldPath = new List<Vector2>();
            foreach (var grid in gridPath)
            {
                Vector2 pos = new Vector2(grid.x * agentRenderer.gridSize * factor, -grid.y * agentRenderer.gridSize * factor);
                worldPath.Add(pos);
            }
            List<Vector2> subdividedPath = new List<Vector2>();
            int subdivisions = 10;
            if (worldPath.Count > 0)
            {
                subdividedPath.Add(worldPath[0]);
                for (int i = 0; i < worldPath.Count - 1; i++)
                {
                    Vector2 p0 = worldPath[i];
                    Vector2 p1 = worldPath[i + 1];
                    for (int s = 1; s < subdivisions; s++)
                    {
                        float t = s / (float)subdivisions;
                        subdividedPath.Add(Vector2.Lerp(p0, p1, t));
                    }
                    subdividedPath.Add(p1);
                }
            }
            agentPaths[name] = subdividedPath;
            Debug.Log($"Agent {name}: ԭ·���ڵ���: {gridPath.Count}��ϸ�ֺ�ڵ���: {subdividedPath.Count}");
        }

        int maxPathLength = 0;
        foreach (var path in agentPaths.Values)
        {
            if (path.Count > maxPathLength)
                maxPathLength = path.Count;
        }
        Debug.Log("�ϸ��·������: " + maxPathLength);
        if (maxPathLength <= 1)
        {
            Debug.Log("���� agent �����ƶ����ȴ� " + duration + " ��");
            yield return new WaitForSeconds(duration);
            yield break;
        }
        float segmentDuration = duration / (maxPathLength - 1);
        Debug.Log("ÿ�ζ���ʱ��: " + segmentDuration + " ��");

        for (int segment = 0; segment < maxPathLength - 1; segment++)
        {
            float elapsed = 0f;
            while (elapsed < segmentDuration)
            {
                float t = elapsed / segmentDuration;
                foreach (var kvp in agentPaths)
                {
                    string name = kvp.Key;
                    List<Vector2> path = kvp.Value;
                    Vector2 fromPos = (segment < path.Count) ? path[segment] : path[path.Count - 1];
                    Vector2 toPos = (segment + 1 < path.Count) ? path[segment + 1] : path[path.Count - 1];
                    Vector2 newPos = Vector2.Lerp(fromPos, toPos, Mathf.Clamp01(t));
                    agentRenderer.UpdateAgentPosition(name, newPos);

                    bool moving = (toPos - fromPos).magnitude > 0.1f;
                    AgentAnimationController.Direction animDir = AgentAnimationController.Direction.Down;
                    if (moving)
                    {
                        if (Mathf.Abs(toPos.x - fromPos.x) >= Mathf.Abs(toPos.y - fromPos.y))
                            animDir = (toPos.x - fromPos.x > 0) ? AgentAnimationController.Direction.Right : AgentAnimationController.Direction.Left;
                        else
                            animDir = (toPos.y - fromPos.y > 0) ? AgentAnimationController.Direction.Up : AgentAnimationController.Direction.Down;
                    }
                    AgentAnimationController animCtrl = agentRenderer.GetAnimationController(name);
                    if (animCtrl != null)
                        animCtrl.UpdateAnimation(animDir, moving, Time.deltaTime);
                }
                elapsed += Time.deltaTime;
                yield return null;
            }
        }
        // ����������ǿ������ agent ��Ϊ idle ״̬
        foreach (var kvp in agentPaths)
        {
            string name = kvp.Key;
            List<Vector2> path = kvp.Value;
            Vector2 lastMovement = Vector2.zero;
            if (path.Count >= 2)
                lastMovement = path[path.Count - 1] - path[path.Count - 2];
            AgentAnimationController.Direction idleDir = AgentAnimationController.Direction.Down;
            if (lastMovement.magnitude > 0.1f)
            {
                if (Mathf.Abs(lastMovement.x) >= Mathf.Abs(lastMovement.y))
                    idleDir = (lastMovement.x > 0) ? AgentAnimationController.Direction.Right : AgentAnimationController.Direction.Left;
                else
                    idleDir = (lastMovement.y > 0) ? AgentAnimationController.Direction.Up : AgentAnimationController.Direction.Down;
            }
            AgentAnimationController animCtrl = agentRenderer.GetAnimationController(name);
            if (animCtrl != null)
                animCtrl.UpdateAnimation(idleDir, false, 0f);
        }
    }
    #endregion

    private void ForceAgentsIdle()
    {
        foreach (var kvp in simulationSteps[currentStepIndex])
        {
            string name = kvp.Key;
            AgentAnimationController animCtrl = agentRenderer.GetAnimationController(name);
            if (animCtrl != null)
                animCtrl.UpdateAnimation(AgentAnimationController.Direction.Down, false, 0f);
        }
    }
}
