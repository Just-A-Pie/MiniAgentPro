[System.Serializable]
public class AttributeEntry
{
    public string key;
    public string value;
}
