using UnityEngine;
using System.IO;

public class SimulationMapRenderer : MonoBehaviour
{
    [Header("������Դ�ļ���")]
    // ���δ���ã����Զ��� GameManager.Instance.resourcePath ��ȡ
    public string mapFolder;

    [Header("����")]
    public RectTransform mapContent;  // ������ʾ����������ĸ�����

    private void Start()
    {
        if (string.IsNullOrEmpty(mapFolder))
        {
            if (GameManager.Instance != null)
                mapFolder = GameManager.Instance.resourcePath;
            else
                Debug.LogError("δ���� mapFolder ��δ�ҵ� GameManager");
        }
        LoadBuildingsAndObjects();
    }

    private void LoadBuildingsAndObjects()
    {
        // �����Ͷ����ļ����� map �ļ���ͬ��
        string buildingDirectory = Path.Combine(mapFolder, "buildings");
        Debug.Log("����Ŀ¼: " + buildingDirectory);
        if (Directory.Exists(buildingDirectory))
        {
            string[] buildingFolders = Directory.GetDirectories(buildingDirectory);
            foreach (string folder in buildingFolders)
            {
                string folderName = Path.GetFileName(folder);
                string jsonPath = Path.Combine(folder, "maze_meta_info.json");
                if (File.Exists(jsonPath))
                {
                    string jsonText = File.ReadAllText(jsonPath);
                    MazeMetaInfo meta = JsonUtility.FromJson<MazeMetaInfo>(jsonText);
                    EditorItem newItem = new EditorItem();
                    newItem.typeId = meta.typeId;
                    newItem.itemName = folderName;  // �� meta.world_name
                    newItem.gridWidth = meta.maze_width;
                    newItem.gridHeight = meta.maze_height;
                    newItem.category = EditorItemCategory.Building;
                    // ʹ�ù̶���ͼ���� "texture.png"
                    string pngPath = Path.Combine(folder, "texture.png");
                    newItem.thumbnail = LoadSpriteFromFile(pngPath);
                    // ����ʾ���н���λ�ù̶�Ϊ (0,0)������ʵ���������
                    SimulationItemCreator.CreateItemInstance(newItem, 0, 0, EditorItemCategory.Building, mapContent);
                }
            }
        }
        else
        {
            Debug.LogWarning("���������ļ��в�����: " + buildingDirectory);
        }

        string objectDirectory = Path.Combine(mapFolder, "objects");
        Debug.Log("����Ŀ¼: " + objectDirectory);
        if (Directory.Exists(objectDirectory))
        {
            string[] objectFolders = Directory.GetDirectories(objectDirectory);
            foreach (string folder in objectFolders)
            {
                string folderName = Path.GetFileName(folder);
                string jsonPath = Path.Combine(folder, "maze_meta_info.json");
                if (File.Exists(jsonPath))
                {
                    string jsonText = File.ReadAllText(jsonPath);
                    MazeMetaInfo meta = JsonUtility.FromJson<MazeMetaInfo>(jsonText);
                    EditorItem newItem = new EditorItem();
                    newItem.typeId = meta.typeId;
                    newItem.itemName = folderName;
                    newItem.gridWidth = meta.maze_width;
                    newItem.gridHeight = meta.maze_height;
                    newItem.category = EditorItemCategory.Object;
                    string pngPath = Path.Combine(folder, "texture.png");
                    newItem.thumbnail = LoadSpriteFromFile(pngPath);
                    // ����λ��ͬ��ʾ����Ϊ (0,0)��������Ҫ����
                    SimulationItemCreator.CreateItemInstance(newItem, 0, 0, EditorItemCategory.Object, mapContent);
                }
            }
        }
        else
        {
            Debug.LogWarning("���������ļ��в�����: " + objectDirectory);
        }
    }

    private Sprite LoadSpriteFromFile(string filePath)
    {
        if (!File.Exists(filePath))
        {
            Debug.LogWarning("�ļ�������: " + filePath);
            return null;
        }
        byte[] fileData = File.ReadAllBytes(filePath);
        Texture2D tex = new Texture2D(2, 2);
        if (tex.LoadImage(fileData))
            return Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), new Vector2(0.5f, 0.5f));
        return null;
    }
}
