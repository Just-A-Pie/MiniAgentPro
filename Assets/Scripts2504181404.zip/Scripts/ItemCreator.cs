using UnityEngine;
using UnityEngine.UI;
using static MapManager;

public static class ItemCreator
{
    public static void CreateItemInstanceWithClick(EditorItem item, int gridX, int gridY, EditorItemCategory cat, RectTransform mapContent, PopupManager popupManager, string uniqueId = null, string itemName = null, System.Collections.Generic.Dictionary<string, string> attributes = null)
    {
        float factor = MapManager.Instance.backgroundScaleFactor;
        Vector2 pos = new Vector2(gridX * 32f * factor, -gridY * 32f * factor);

        // �½���Ʒʵ���������� Image ���
        GameObject go = new GameObject($"{cat}_Loaded", typeof(Image));
        go.transform.SetParent(mapContent, false);
        Image img = go.GetComponent<Image>();
        img.sprite = item.thumbnail;
        RectTransform rt = img.rectTransform;
        rt.sizeDelta = new Vector2(item.gridWidth * 32f * factor, item.gridHeight * 32f * factor);
        rt.pivot = new Vector2(0, 1);
        rt.anchorMin = new Vector2(0, 1);
        rt.anchorMax = new Vector2(0, 1);
        rt.anchoredPosition = pos;

        if (cat == EditorItemCategory.Object)
            go.transform.SetAsLastSibling();
        else
            go.transform.SetSiblingIndex(mapContent.childCount - 1);

        if (string.IsNullOrEmpty(uniqueId))
            uniqueId = System.Guid.NewGuid().ToString();

        go.name = uniqueId;

        if (string.IsNullOrEmpty(itemName))
            itemName = item.itemName;

        // ���� EditorItem �ĸ�������������ֵ�
        EditorItem copiedItem = new EditorItem
        {
            uniqueId = uniqueId,
            typeId = item.typeId,
            itemName = itemName,
            gridWidth = item.gridWidth,
            gridHeight = item.gridHeight,
            category = item.category,
            thumbnail = item.thumbnail,
            attributes = attributes != null ? new System.Collections.Generic.Dictionary<string, string>(attributes) : new System.Collections.Generic.Dictionary<string, string>()
        };

        PlacedItem placedItem = new PlacedItem
        {
            uniqueId = uniqueId,
            item = copiedItem,
            category = cat,
            typeId = item.typeId,
            gridX = gridX,
            gridY = gridY,
            gridWidth = item.gridWidth,
            gridHeight = item.gridHeight
        };

        MapManager.Instance.placedItems.Add(placedItem);

        // ���ӵ���¼��������򿪱༭����
        Button btn = go.AddComponent<Button>();
        btn.onClick.AddListener(() => OnItemClicked(placedItem, popupManager));

        // === �ؼ��޸ģ���̬���� ContainerLogoController ��� ===
        ContainerLogoController logoCtrl = go.GetComponent<ContainerLogoController>();
        if (logoCtrl == null)
        {
            logoCtrl = go.AddComponent<ContainerLogoController>();
            // �����Ҫͳһ����Ĭ�� Sprite�����ڴ˴��ֶ���ֵ�����磺
            // logoCtrl.containerLogoSprite = Resources.Load<Sprite>("ContainerLogo");
        }
        // �ж���Ʒ�������Ƿ��� container ���ԣ��ǿ��ַ����������� logo ��ʾ״̬
        bool hasContainer = (copiedItem.attributes != null &&
                             copiedItem.attributes.ContainsKey("container") &&
                             !string.IsNullOrEmpty(copiedItem.attributes["container"]));
        logoCtrl.UpdateLogoVisibility(hasContainer);
        // ===========================================================
    }

    private static void OnItemClicked(PlacedItem selected, PopupManager popupManager)
    {
        // ÿ�ε��ʱ��ȫ�������в���������Ʒ����
        PlacedItem updated = MapManager.Instance.placedItems.Find(x => x.uniqueId == selected.uniqueId);
        if (popupManager != null)
        {
            popupManager.ShowPopup(updated);
        }
        else
        {
            Debug.LogError("PopupManager δ�󶨣�");
        }
    }
}
