using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using System.IO;
using static MapManager;

public class BuildingPlacementController : MonoBehaviour, IPointerMoveHandler, IPointerClickHandler
{
    [Header("���ò���")]
    public RectTransform mapContent;
    public float gridSize = 32f;
    public GameObject previewPrefab;

    private GameObject previewInstance;

    public PopupManager popupManager;  // ����������

    public void OnPointerMove(PointerEventData eventData)
    {
        UpdatePreviewPosition(eventData);
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        if (eventData.button != PointerEventData.InputButton.Left)
            return;

        // ��������ƶ�ģʽ��������ƶ�����
        if (MapManager.Instance.isMoveMode)
        {
            MoveItem(eventData);
            return;
        }

        PlaceItem(eventData);
    }

    void Update()
    {
        EditorItem selected = EditorManager.Instance.currentSelectedItem;
        // ���ѡ����һ����Ʒ��Building �� Object��
        if (selected != null && (selected.category == EditorItemCategory.Building || selected.category == EditorItemCategory.Object))
        {
            if (previewInstance == null && previewPrefab != null)
            {
                previewInstance = Instantiate(previewPrefab, mapContent);
                RectTransform rt = previewInstance.GetComponent<RectTransform>();
                rt.pivot = new Vector2(0, 1);  // ���Ͻ�ê��
            }

            if (previewInstance != null)
            {
                Image img = previewInstance.GetComponent<Image>();
                if (img != null)
                {
                    img.sprite = selected.thumbnail;
                    float factor = MapManager.Instance.backgroundScaleFactor;
                    Vector2 newSize = new Vector2(selected.gridWidth * gridSize * factor, selected.gridHeight * gridSize * factor);
                    previewInstance.GetComponent<RectTransform>().sizeDelta = newSize;
                }
                // Ԥ��ʼ���
                previewInstance.transform.SetAsLastSibling();
            }
        }
        else
        {
            if (previewInstance != null)
            {
                Destroy(previewInstance);
                previewInstance = null;
            }
        }
    }

    private void UpdatePreviewPosition(PointerEventData eventData)
    {
        EditorItem selected = EditorManager.Instance.currentSelectedItem;
        if (selected == null || (selected.category != EditorItemCategory.Building && selected.category != EditorItemCategory.Object))
            return;

        Vector2 localPoint;
        // ����Ļ����ת��Ϊ����� mapContent ���Ͻǵı�������
        if (RectTransformUtility.ScreenPointToLocalPointInRectangle(
            mapContent, eventData.position, eventData.pressEventCamera, out localPoint))
        {
            float factor = MapManager.Instance.backgroundScaleFactor;

            int gridX = Mathf.FloorToInt(localPoint.x / (gridSize * factor));
            int gridY = Mathf.FloorToInt(-localPoint.y / (gridSize * factor));

            Vector2 snappedPos = new Vector2(
                gridX * gridSize * factor,
                -gridY * gridSize * factor
            );

            if (previewInstance != null)
            {
                RectTransform rt = previewInstance.GetComponent<RectTransform>();
                rt.anchoredPosition = snappedPos;
                // �ö�
                previewInstance.transform.SetAsLastSibling();
            }
        }
    }

    private void PlaceItem(PointerEventData eventData)
    {
        EditorItem selected = EditorManager.Instance.currentSelectedItem;
        if (selected == null || (selected.category != EditorItemCategory.Building && selected.category != EditorItemCategory.Object))
            return;

        Vector2 localPoint;
        if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(
            mapContent, eventData.position, eventData.pressEventCamera, out localPoint))
            return;

        float factor = MapManager.Instance.backgroundScaleFactor;
        int gridX = Mathf.FloorToInt(localPoint.x / (gridSize * factor));
        int gridY = Mathf.FloorToInt(-localPoint.y / (gridSize * factor));

        // ���ù�������������Ʒ���󶨵���¼�
        ItemCreator.CreateItemInstanceWithClick(selected, gridX, gridY, selected.category, mapContent, popupManager);
        // ������Ʒ�󣬱�ǵ�ͼ�������޸�
        MapManager.Instance.isDirty = true;
    }

    // �����������ƶ�ģʽ�¸�����Ʒλ��
    private void MoveItem(PointerEventData eventData)
    {
        // ��ȡȫ���д��ƶ�����Ʒ�����������ã�
        PlacedItem movingItem = MapManager.Instance.movingItem;

        Vector2 localPoint;
        if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(
            mapContent, eventData.position, eventData.pressEventCamera, out localPoint))
            return;

        float factor = MapManager.Instance.backgroundScaleFactor;
        int gridX = Mathf.FloorToInt(localPoint.x / (gridSize * factor));
        int gridY = Mathf.FloorToInt(-localPoint.y / (gridSize * factor));

        // �����ƶ���Ʒ������
        movingItem.gridX = gridX;
        movingItem.gridY = gridY;

        // ���� UI λ�ã��� mapContent �в��Ҹ���Ʒ
        foreach (Transform child in mapContent)
        {
            if (child.gameObject.name == movingItem.uniqueId)
            {
                RectTransform rt = child.GetComponent<RectTransform>();
                if (rt != null)
                {
                    rt.anchoredPosition = new Vector2(gridX * gridSize * factor, -gridY * gridSize * factor);
                }
                break;
            }
        }

        // ͬ������ȫ�� placedItems �ж�Ӧ��¼
        for (int i = 0; i < MapManager.Instance.placedItems.Count; i++)
        {
            if (MapManager.Instance.placedItems[i].uniqueId == movingItem.uniqueId)
            {
                MapManager.Instance.placedItems[i] = movingItem;
                break;
            }
        }
        MapManager.Instance.isDirty = true;

        // �˳��ƶ�ģʽ
        MapManager.Instance.isMoveMode = false;
        MapManager.Instance.movingItem = default(PlacedItem);

        // ���Ԥ����ȡ��ѡ��״̬
        if (previewInstance != null)
        {
            Destroy(previewInstance);
            previewInstance = null;
        }
        EditorManager.Instance.SetSelectedItem(null);

        Debug.Log($"��Ʒ�ƶ���ɣ���λ��: ({gridX}, {gridY})");
    }
}
