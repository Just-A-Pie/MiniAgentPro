﻿// 文件：InformationPanelController.cs
using UnityEngine;
using UnityEngine.UI;
using TMPro;
/// <summary>
/// 控制信息面板的显示，包括 Agent 信息和 Object/Building 信息
/// </summary>
public class InformationPanelController : MonoBehaviour
{
    [Header("Group Parents")]
    public GameObject agentInfoGroup;    // Canvas/InformationPanel/AgentInformation
    public GameObject otherInfoGroup;    // Canvas/InformationPanel/OtherInformation

    [Header("Agent Fields")]
    public TMP_Text nameText;
    public TMP_Text positionText;
    public TMP_Text locationText;
    public TMP_Text activityText;
    public TMP_Text bagText;
    public Image agentIcon;

    [Header("Other Fields")]
    public TMP_Text otherNameText;
    public TMP_Text otherTypeText;
    public TMP_Text otherPositionText;
    public TMP_Text otherAttributesText; // 用于显示属性
    public Image otherIcon;

    public void SetAgentInfo(SimulationAgent agent, Vector2Int tile)
    {
        agentInfoGroup.SetActive(true);
        otherInfoGroup.SetActive(false);

        nameText.text = agent.name;
        positionText.text = $"{tile.x}, {tile.y}";
        locationText.text = agent.location ?? "";
        activityText.text = agent.activity ?? "";

        string[] ignored = { "menu", "notebooks", "clothes", "body wash" };
        var filtered = System.Array.FindAll(agent.bag ?? new string[0],
            item => System.Array.IndexOf(ignored, item.ToLower()) == -1);
        bagText.text = string.Join(", ", filtered);

        string baseName = agent.walkingSpriteSheetName ?? agent.name;
        agentIcon.sprite = TryLoadFirstFrameSprite(baseName);
    }

    public void SetOtherInfo(MapManager.PlacedItem placed)
    {
        Debug.Log($"[InformationPanel] ► SetOtherInfo START id={placed.uniqueId}");

        otherInfoGroup.SetActive(true);
        agentInfoGroup.SetActive(false);

        // 基本信息
        otherNameText.text = placed.item.itemName;
        otherTypeText.text = placed.category.ToString();
        otherPositionText.text = $"({placed.gridX}, {placed.gridY})";

        // 属性拼接
        Debug.Log("[InformationPanel] Processing attributes...");
        if (placed.item.attributes != null && placed.item.attributes.Count > 0)
        {
            Debug.Log($"[InformationPanel] Found {placed.item.attributes.Count} attributes");
            var parts = new System.Collections.Generic.List<string>();
            foreach (var kv in placed.item.attributes)
            {
                Debug.Log($"[InformationPanel] Attribute key={kv.Key}, value={kv.Value}");
                if (kv.Key == "container" && !string.IsNullOrEmpty(kv.Value))
                {
                    Debug.Log("[InformationPanel] ► Entering container branch");
                    var ids = kv.Value.Split(',');
                    var names = new System.Collections.Generic.List<string>();
                    foreach (var id in ids)
                    {
                        if (SimulationUIController.Instance != null &&
                            SimulationUIController.Instance.TryGetItemName(id, out var childName))
                        {
                            Debug.Log($"[InformationPanel]  → Found child {id} name={childName}");
                            names.Add(childName);
                        }
                        else
                        {
                            Debug.LogWarning($"[InformationPanel]  → Child id={id} NOT found, fallback to ID");
                            names.Add(id);
                        }
                    }
                    var joinedNames = string.Join(", ", names);
                    Debug.Log($"[InformationPanel] container names = {joinedNames}");
                    parts.Add($"container: {joinedNames}");
                }
                else
                {
                    Debug.Log($"[InformationPanel] ► Normal attribute {kv.Key}: {kv.Value}");
                    parts.Add($"{kv.Key}: {kv.Value}");
                }
            }
            otherAttributesText.text = string.Join(", ", parts);
            Debug.Log($"[InformationPanel] otherAttributesText = \"{otherAttributesText.text}\"");
        }
        else
        {
            Debug.Log("[InformationPanel] No attributes to process");
            otherAttributesText.text = "";
        }

        // 图标缩放
        Debug.Log("[InformationPanel] Processing icon...");
        otherIcon.sprite = placed.item.thumbnail;
        if (placed.item.thumbnail != null)
        {
            float origW = placed.item.thumbnail.rect.width;
            float origH = placed.item.thumbnail.rect.height;
            Debug.Log($"[InformationPanel] origW={origW}, origH={origH}");
            float scaleFactor = Mathf.Min(75f / origW, 75f / origH, 1f);
            Debug.Log($"[InformationPanel] scaleFactor={scaleFactor}");
            otherIcon.rectTransform.sizeDelta = new Vector2(origW * scaleFactor, origH * scaleFactor);
            Debug.Log($"[InformationPanel] Icon sized to {otherIcon.rectTransform.sizeDelta}");
        }
        else
        {
            Debug.LogWarning("[InformationPanel] placed.item.thumbnail is null, skipping scale");
        }

        Debug.Log("[InformationPanel] ◄ SetOtherInfo END");
    }

    public void Clear()
    {
        agentInfoGroup.SetActive(false);
        otherInfoGroup.SetActive(false);

        nameText.text = positionText.text = locationText.text =
            activityText.text = bagText.text = "";
        agentIcon.sprite = null;

        otherNameText.text = otherTypeText.text = otherPositionText.text = "";
        otherAttributesText.text = "";
        otherIcon.sprite = null;
    }

    private Sprite TryLoadFirstFrameSprite(string baseName)
    {
        string[] tryNames = new string[]
        {
            baseName,
            baseName.Contains("_") ? baseName.Replace("_", " ") : baseName.Replace(" ", "_")
        };

        foreach (string name in tryNames)
        {
            Sprite[] sprites = Resources.LoadAll<Sprite>(name);
            if (sprites != null && sprites.Length > 0)
            {
                foreach (var spr in sprites)
                    if (spr.name.EndsWith("_1"))
                        return spr;
                return sprites[0];
            }
        }
        Debug.LogWarning($"贴图加载失败: {baseName}");
        return null;
    }
}
