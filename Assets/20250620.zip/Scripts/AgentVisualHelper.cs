using UnityEngine;
using UnityEngine.UI;

public class AgentVisualHelper : MonoBehaviour
{
    public Outline outlineComponent;
}
