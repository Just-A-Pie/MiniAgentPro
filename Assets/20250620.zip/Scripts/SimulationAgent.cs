[System.Serializable]
public class SimulationAgent
{
    public string name;
    public string activity;
    public string location;
    public string[] bag;
    public int[] curr_tile;
    public string short_activity;
    public string walkingSpriteSheetName;
}
