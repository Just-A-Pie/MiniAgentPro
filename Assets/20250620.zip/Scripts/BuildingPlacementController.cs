// �ļ�: BuildingPlacementController.cs
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using static MapManager;

public class BuildingPlacementController : MonoBehaviour, IPointerMoveHandler, IPointerClickHandler
{
    [Header("���ò���")]
    public RectTransform mapContent;
    public float gridSize = 32f;
    public GameObject previewPrefab;

    private GameObject previewInstance;
    public PopupManager popupManager;

    public void OnPointerMove(PointerEventData eventData)
    {
        UpdatePreviewPosition(eventData);
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        if (eventData.button != PointerEventData.InputButton.Left)
            return;

        if (MapManager.Instance.isMoveMode)
        {
            MoveItem(eventData);
            return;
        }

        PlaceItem(eventData);
    }

    void Update()
    {
        var selected = EditorManager.Instance.currentSelectedItem;
        bool isItem = selected != null &&
                      (selected.category == EditorItemCategory.Building ||
                       selected.category == EditorItemCategory.Object);
        if (isItem)
        {
            if (previewInstance == null && previewPrefab != null)
            {
                previewInstance = Instantiate(previewPrefab, mapContent);
                previewInstance.GetComponent<RectTransform>().pivot = new Vector2(0, 1);
            }
            if (previewInstance != null)
            {
                UpdatePreviewPosition(null); // �����߼�
                previewInstance.transform.SetAsLastSibling();
            }
        }
        else
        {
            if (previewInstance != null)
            {
                Destroy(previewInstance);
                previewInstance = null;
            }
        }
    }

    private void UpdatePreviewPosition(PointerEventData eventData)
    {
        var selected = EditorManager.Instance.currentSelectedItem;
        if (selected == null) return;

        Vector2 localPoint;
        if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(
            mapContent, eventData.position, eventData.pressEventCamera, out localPoint))
            return;

        float factor = MapManager.Instance.backgroundScaleFactor;
        int gridX = Mathf.FloorToInt(localPoint.x / (gridSize * factor));
        int gridY = Mathf.FloorToInt(-localPoint.y / (gridSize * factor));
        Vector2 snappedPos = new Vector2(gridX * gridSize * factor, -gridY * gridSize * factor);

        if (previewInstance != null)
            previewInstance.GetComponent<RectTransform>().anchoredPosition = snappedPos;
    }

    private void PlaceItem(PointerEventData eventData)
    {
        var selected = EditorManager.Instance.currentSelectedItem;
        if (selected == null) return;

        Vector2 localPoint;
        if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(
            mapContent, eventData.position, eventData.pressEventCamera, out localPoint))
            return;

        float factor = MapManager.Instance.backgroundScaleFactor;
        int gridX = Mathf.FloorToInt(localPoint.x / (gridSize * factor));
        int gridY = Mathf.FloorToInt(-localPoint.y / (gridSize * factor));

        ItemCreator.CreateItemInstanceWithClick(
            selected, gridX, gridY, selected.category,
            mapContent, popupManager);

        MapManager.Instance.isDirty = true;
        if (GridOverlayManager.Instance != null &&
            GridOverlayManager.Instance.currentMode != GridOverlayManager.OverlayMode.None)
        {
            GridOverlayManager.Instance.RefreshOverlay();
        }
    }

    private void MoveItem(PointerEventData eventData)
    {
        var movingItem = MapManager.Instance.movingItem;

        Vector2 localPoint;
        if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(
            mapContent, eventData.position, eventData.pressEventCamera, out localPoint))
            return;

        float factor = MapManager.Instance.backgroundScaleFactor;
        int gridX = Mathf.FloorToInt(localPoint.x / (gridSize * factor));
        int gridY = Mathf.FloorToInt(-localPoint.y / (gridSize * factor));

        movingItem.gridX = gridX;
        movingItem.gridY = gridY;

        foreach (Transform child in mapContent)
        {
            if (child.name == movingItem.uniqueId)
            {
                var rt = child.GetComponent<RectTransform>();
                rt.anchoredPosition = new Vector2(gridX * gridSize * factor, -gridY * gridSize * factor);
                var logo = child.GetComponent<ContainerLogoController>();
                if (logo != null) logo.RefreshLogoPosition();
                break;
            }
        }

        for (int i = 0; i < MapManager.Instance.placedItems.Count; i++)
        {
            if (MapManager.Instance.placedItems[i].uniqueId == movingItem.uniqueId)
            {
                MapManager.Instance.placedItems[i] = movingItem;
                break;
            }
        }

        // ����ಢˢ�� Overlay
        MapManager.Instance.isDirty = true;
        if (GridOverlayManager.Instance != null &&
            GridOverlayManager.Instance.currentMode != GridOverlayManager.OverlayMode.None)
        {
            GridOverlayManager.Instance.RefreshOverlay();
        }

        MapManager.Instance.isMoveMode = false;
        MapManager.Instance.movingItem = default(PlacedItem);

        if (previewInstance != null)
        {
            Destroy(previewInstance);
            previewInstance = null;
        }
        EditorManager.Instance.SetSelectedItem(null);

        Debug.Log($"��Ʒ�ƶ���ɣ���λ��: ({gridX}, {gridY})");
    }
}
